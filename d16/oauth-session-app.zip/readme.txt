1. Install dependencies
npm install

2. Configure Google OAuth on Google Cloud Platform
Refer documentation

3. Update .env:
GOOGLE_CLIENT_ID=your_client_id_here
GOOGLE_CLIENT_SECRET=your_client_secret_here

4. npm start
Server runs at:
http://localhost:5000 

5. Login
http://localhost:5000

Login via Google → redirected to profile.html.

7.Click Logout

Request to GET /logout


